// server.js
import express from "express";
import cors from "cors";
import fetch from "node-fetch";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.static(path.join(__dirname, "index.html")));

const API_KEY = "5c71f719fa9e411e80698109c91ba23f";
const BASE_URL = "https://newsapi.org/v2";

// News endpoint
app.get("/api/news", async (req, res) => {
  try {
    const response = await fetch(`${BASE_URL}/top-headlines?country=us&apiKey=${API_KEY}`);
    const data = await response.json();
    res.json(data);
  } catch (err) {
    console.error("Error fetching news:", err);
    res.status(500).json({ error: "Failed to fetch news" });
  }
});

// Fallback route (safe way)
app.use((req, res, next) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

app.listen(PORT, () => {
  console.log(`✅ NEWZON server running at http://localhost:${PORT}`);
});
