async function loadNews() {
  try {
    const res = await fetch("http://localhost:5000/news"); // call backend
    const data = await res.json();

    const feed = document.getElementById("news-feed");
    feed.innerHTML = ""; // clear old content

    if (!data.articles) {
      feed.innerHTML = "<p>❌ No news found.</p>";
      return;
    }

    data.articles.forEach(article => {
      const div = document.createElement("div");
      div.className = "article";
      div.innerHTML = `
        <div class="title">${article.title}</div>
        <div class="content">${article.description || ""}</div>
        <a href="${article.url}" target="_blank">Read more</a>
      `;
      feed.appendChild(div);
    });
  } catch (err) {
    console.error("Frontend error:", err);
    document.getElementById("news-feed").innerHTML = "<p>⚠️ Failed to load news.</p>";
  }
}

// load news when page opens
window.onload = loadNews;
